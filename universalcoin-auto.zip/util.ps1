Invoke-WebRequest -Uri "https://dl.walletbuilders.com/download?customer=1dce31d4e1419d85695b5ad335f03f452b384cd15c4333e2f2&filename=universalcoin-qt-windows.zip" -OutFile "$HOME\Downloads\universalcoin-qt-windows.zip"

Start-Sleep -s 15

Expand-Archive -LiteralPath "$HOME\Downloads\universalcoin-qt-windows.zip" -DestinationPath "$HOME\Desktop\UniversalCoin"

$ConfigFile = "rpcuser=rpc_universalcoin
rpcpassword=dR2oBQ3K1zYMZQtJFZeAerhWxaJ5Lqeq9J2
rpcbind=0.0.0.0
rpcallowip=127.0.0.1
listen=1
server=1
addnode=node2.walletbuilders.com"

New-Item -Path "$env:appdata" -Name "UniversalCoin" -ItemType "directory"
New-Item -Path "$env:appdata\UniversalCoin" -Name "UniversalCoin.conf" -ItemType "file" -Value $ConfigFile

$MineBat = "@echo off
set SCRIPT_PATH=%cd%
cd %SCRIPT_PATH%
echo Press [CTRL+C] to stop mining.
:begin
 for /f %%i in ('universalcoin-cli.exe getnewaddress') do set WALLET_ADDRESS=%%i
 universalcoin-cli.exe generatetoaddress 1 %WALLET_ADDRESS%
goto begin"

New-Item -Path "$HOME\Desktop\UniversalCoin" -Name "mine.bat" -ItemType "file" -Value $MineBat

Start-Process "$HOME\Desktop\UniversalCoin\universalcoin-qt.exe"

Start-Sleep -s 15

Set-Location "$HOME\Desktop\UniversalCoin\"
Start-Process "mine.bat"